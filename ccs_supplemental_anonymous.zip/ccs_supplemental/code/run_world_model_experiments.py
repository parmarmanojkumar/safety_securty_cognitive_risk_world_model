#!/usr/bin/env python3
"""
World-model safety experiments.
Anonymised for CCS 2026 double-blind review.

This script generates:
1) Baseline trajectory-persistence metrics (deterministic GRU WM vs single-step model)
2) Symmetric-vs-asymmetric Definition 1 comparison
3) Mitigation ablation via adversarial training
4) RSSM-proxy validation (stochastic posterior/prior loop approximation)
5) Figures and CSV tables for direct inclusion in the paper
"""

from __future__ import annotations

import json
import math
import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

# Keep matplotlib cache writable in sandboxed environments.
os.environ.setdefault(
    "MPLCONFIGDIR",
    "/tmp/.mplcache",  # set to a writable temp dir for your environment
)

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


@dataclass
class Config:
    seed: int = 42
    device: str = "cpu"
    do: int = 32
    da: int = 8
    dz: int = 16
    dh: int = 64
    seq_len: int = 30
    n_train: int = 1200
    n_test: int = 300
    noise_x: float = 0.02
    noise_o: float = 0.03
    batch_size: int = 64
    epochs_ss: int = 18
    epochs_gru: int = 22
    epochs_rssm: int = 26
    lr: float = 2e-3
    n_trials: int = 200
    eps_default: float = 0.05
    eps_grid: Tuple[float, ...] = (0.0, 0.02, 0.05, 0.1, 0.2, 0.35, 0.5)
    horizons: Tuple[int, ...] = (5, 10, 15, 20, 25, 30)
    eps_floor: float = 1e-6
    adv_ft_epochs: int = 8
    adv_ft_eps: float = 0.05
    adv_ft_lambda: float = 0.7
    adv_ft_lambda_sens: float = 0.8
    adv_ft_steps: int = 10
    adv_ft_step_size: float = 0.015


def stable_matrix(dim: int, scale: float = 0.88) -> torch.Tensor:
    m = torch.randn(dim, dim)
    eig = torch.linalg.eigvals(m).abs().max().real.item()
    return (m / eig) * scale


def build_synth_dataset(cfg: Config) -> Dict[str, torch.Tensor]:
    """
    Hidden state dynamics:
      x_{t+1} = A x_t + B u_t + noise
      o_t     = C x_t + noise
    """
    A = stable_matrix(cfg.dz, scale=0.9)
    B = torch.randn(cfg.dz, cfg.da) * 0.25
    C = torch.randn(cfg.do, cfg.dz) * 0.45

    def sample(n: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        acts = torch.randn(n, cfg.seq_len, cfg.da)
        x = torch.zeros(n, cfg.seq_len, cfg.dz)
        o = torch.zeros(n, cfg.seq_len, cfg.do)
        x[:, 0] = torch.randn(n, cfg.dz) * 0.35
        o[:, 0] = x[:, 0] @ C.T + cfg.noise_o * torch.randn(n, cfg.do)
        for t in range(cfg.seq_len - 1):
            x[:, t + 1] = (
                x[:, t] @ A.T
                + acts[:, t] @ B.T
                + cfg.noise_x * torch.randn(n, cfg.dz)
            )
            o[:, t + 1] = x[:, t + 1] @ C.T + cfg.noise_o * torch.randn(n, cfg.do)
        return o, acts, x

    o_train, a_train, x_train = sample(cfg.n_train)
    o_test, a_test, x_test = sample(cfg.n_test)
    return {
        "o_train": o_train,
        "a_train": a_train,
        "x_train": x_train,
        "o_test": o_test,
        "a_test": a_test,
        "x_test": x_test,
    }


class SingleStepModel(nn.Module):
    def __init__(self, cfg: Config):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(cfg.do + cfg.da, 128),
            nn.ReLU(),
            nn.Linear(128, cfg.dz),
        )

    def forward(self, obs: torch.Tensor, acts: torch.Tensor) -> torch.Tensor:
        # obs: [B,T,do], acts: [B,T,da]
        x = torch.cat([obs, acts], dim=-1)
        return self.net(x)  # [B,T,dz]


class GRUWorldModel(nn.Module):
    def __init__(self, cfg: Config):
        super().__init__()
        self.enc = nn.Sequential(nn.Linear(cfg.do, cfg.dh), nn.Tanh())
        self.gru = nn.GRUCell(cfg.dh + cfg.da, cfg.dh)
        self.head = nn.Linear(cfg.dh, cfg.dz)
        self.dh = cfg.dh

    def forward(self, obs: torch.Tensor, acts: torch.Tensor) -> torch.Tensor:
        b, t, _ = obs.shape
        h = torch.zeros(b, self.dh, device=obs.device)
        zs = []
        for i in range(t):
            e = self.enc(obs[:, i])
            h = self.gru(torch.cat([e, acts[:, i]], dim=-1), h)
            z = self.head(h)
            zs.append(z)
        return torch.stack(zs, dim=1)  # [B,T,dz]


class RSSMProxy(nn.Module):
    """
    Lightweight stochastic RSSM-like model:
    - deterministic recurrent state h_t
    - prior p(z_t|h_t), posterior q(z_t|h_t,o_t)
    - decoder predicts true hidden state x_t
    """

    def __init__(self, cfg: Config):
        super().__init__()
        self.obs_enc = nn.Sequential(nn.Linear(cfg.do, cfg.dh), nn.ELU())
        self.gru = nn.GRUCell(cfg.dz + cfg.da, cfg.dh)
        self.prior = nn.Linear(cfg.dh, 2 * cfg.dz)
        self.post = nn.Linear(2 * cfg.dh, 2 * cfg.dz)
        self.dec = nn.Sequential(
            nn.Linear(cfg.dh + cfg.dz, 128),
            nn.ELU(),
            nn.Linear(128, cfg.dz),
        )
        self.dh = cfg.dh
        self.dz = cfg.dz

    def _split_params(self, p: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        mu, logstd = p.chunk(2, dim=-1)
        logstd = torch.clamp(logstd, -4.0, 2.0)
        return mu, logstd

    def forward(
        self,
        obs: torch.Tensor,
        acts: torch.Tensor,
        use_posterior: bool = True,
        posterior_mode: str = "all",
        noise_eps: torch.Tensor | None = None,
    ) -> Dict[str, torch.Tensor]:
        b, t, _ = obs.shape
        h = torch.zeros(b, self.dh, device=obs.device)
        z_prev = torch.zeros(b, self.dz, device=obs.device)
        zs, xhats, kl_terms = [], [], []

        if noise_eps is None:
            noise_eps = torch.randn(b, t, self.dz, device=obs.device)

        for i in range(t):
            h = self.gru(torch.cat([z_prev, acts[:, i]], dim=-1), h)
            p_mu, p_logstd = self._split_params(self.prior(h))
            use_post_t = False
            if use_posterior and posterior_mode == "all":
                use_post_t = True
            elif use_posterior and posterior_mode == "first_only" and i == 0:
                use_post_t = True

            if use_post_t:
                oenc = self.obs_enc(obs[:, i])
                q_mu, q_logstd = self._split_params(self.post(torch.cat([h, oenc], dim=-1)))
            else:
                q_mu, q_logstd = p_mu, p_logstd

            z = q_mu + noise_eps[:, i] * torch.exp(q_logstd)
            xhat = self.dec(torch.cat([h, z], dim=-1))

            # KL(q||p) for diagonal Gaussian.
            kl = (
                p_logstd
                - q_logstd
                + (torch.exp(2 * q_logstd) + (q_mu - p_mu) ** 2)
                / (2 * torch.exp(2 * p_logstd) + 1e-8)
                - 0.5
            ).sum(dim=-1)

            zs.append(z)
            xhats.append(xhat)
            kl_terms.append(kl)
            z_prev = z

        return {
            "z": torch.stack(zs, dim=1),
            "xhat": torch.stack(xhats, dim=1),
            "kl": torch.stack(kl_terms, dim=1),
        }


def iterate_minibatches(
    obs: torch.Tensor, acts: torch.Tensor, xtrue: torch.Tensor, bs: int
) -> List[Tuple[torch.Tensor, torch.Tensor, torch.Tensor]]:
    n = obs.shape[0]
    idx = torch.randperm(n)
    batches = []
    for i in range(0, n, bs):
        j = idx[i : i + bs]
        batches.append((obs[j], acts[j], xtrue[j]))
    return batches


def train_ss(cfg: Config, model: SingleStepModel, data: Dict[str, torch.Tensor]) -> List[float]:
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    losses = []
    for _ in range(cfg.epochs_ss):
        epoch = 0.0
        for obs, acts, xtrue in iterate_minibatches(
            data["o_train"], data["a_train"], data["x_train"], cfg.batch_size
        ):
            pred = model(obs, acts)
            loss = F.mse_loss(pred, xtrue)
            opt.zero_grad()
            loss.backward()
            opt.step()
            epoch += loss.item()
        losses.append(epoch)
    return losses


def train_gru(cfg: Config, model: GRUWorldModel, data: Dict[str, torch.Tensor]) -> List[float]:
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    losses = []
    for _ in range(cfg.epochs_gru):
        epoch = 0.0
        for obs, acts, xtrue in iterate_minibatches(
            data["o_train"], data["a_train"], data["x_train"], cfg.batch_size
        ):
            pred = model(obs, acts)
            loss = F.mse_loss(pred, xtrue)
            opt.zero_grad()
            loss.backward()
            opt.step()
            epoch += loss.item()
        losses.append(epoch)
    return losses


def train_rssm(cfg: Config, model: RSSMProxy, data: Dict[str, torch.Tensor]) -> List[float]:
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    losses = []
    for _ in range(cfg.epochs_rssm):
        epoch = 0.0
        for obs, acts, xtrue in iterate_minibatches(
            data["o_train"], data["a_train"], data["x_train"], cfg.batch_size
        ):
            out = model(obs, acts, use_posterior=True)
            recon = F.mse_loss(out["xhat"], xtrue)
            kl = out["kl"].mean()
            loss = recon + 0.01 * kl
            opt.zero_grad()
            loss.backward()
            opt.step()
            epoch += loss.item()
        losses.append(epoch)
    return losses


def l2_normalize(v: torch.Tensor, eps: float = 1e-9) -> torch.Tensor:
    n = torch.norm(v, p=2, dim=-1, keepdim=True)
    return v / (n + eps)


def wm_attack_delta_gru(
    model: GRUWorldModel,
    obs: torch.Tensor,
    acts: torch.Tensor,
    xtrue: torch.Tensor,
    eps: float,
    target_step: int = 1,
) -> torch.Tensor:
    """
    Computes a single adversarial perturbation applied at t=0 only.
    """
    obs = obs.clone().detach()
    acts = acts.clone().detach()
    obs_var = obs.clone().detach().requires_grad_(True)
    adv_obs = obs_var.unsqueeze(0)
    adv_pred = model(adv_obs, acts.unsqueeze(0))
    # Maximize prediction error at the early planning-relevant step.
    obj = F.mse_loss(adv_pred[0, target_step], xtrue[target_step])
    obj.backward()
    grad = obs_var.grad[0].detach()
    delta = eps * l2_normalize(grad.unsqueeze(0)).squeeze(0)
    return delta


def wm_attack_delta_rssm(
    model: RSSMProxy,
    obs: torch.Tensor,
    acts: torch.Tensor,
    xtrue: torch.Tensor,
    eps: float,
    target_step: int = 1,
) -> torch.Tensor:
    obs = obs.clone().detach()
    acts = acts.clone().detach()
    noise = torch.randn(1, obs.shape[0], model.dz)
    obs_var = obs.clone().detach().requires_grad_(True)
    adv_out = model(
        obs_var.unsqueeze(0),
        acts.unsqueeze(0),
        use_posterior=True,
        posterior_mode="first_only",
        noise_eps=noise,
    )["xhat"]
    obj = F.mse_loss(adv_out[0, target_step], xtrue[target_step])
    obj.backward()
    grad = obs_var.grad[0].detach()
    delta = eps * l2_normalize(grad.unsqueeze(0)).squeeze(0)
    return delta


def apply_delta_at_step(obs: torch.Tensor, delta: torch.Tensor, step: int) -> torch.Tensor:
    out = obs.clone()
    out[step] = out[step] + delta
    return out


def se(arr: np.ndarray) -> float:
    if arr.size <= 1:
        return 0.0
    return float(arr.std(ddof=1) / math.sqrt(arr.size))


def evaluate_gru_vs_ss(
    cfg: Config,
    wm: GRUWorldModel,
    ss: SingleStepModel,
    data: Dict[str, torch.Tensor],
    eps: float,
) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(cfg.seed + 7)
    o_test, a_test, x_test = data["o_test"], data["a_test"], data["x_test"]
    t = cfg.seq_len

    wm_err = np.zeros((cfg.n_trials, t), dtype=np.float64)
    ss_err_asym = np.zeros((cfg.n_trials, t), dtype=np.float64)
    ss_err_sym = np.zeros((cfg.n_trials, t), dtype=np.float64)
    wm_rew_gap = np.zeros((cfg.n_trials, len(cfg.horizons)), dtype=np.float64)
    ss_rew_gap = np.zeros((cfg.n_trials, len(cfg.horizons)), dtype=np.float64)
    wm_clean_abs = np.zeros((cfg.n_trials, len(cfg.horizons)), dtype=np.float64)
    wm_adv_abs = np.zeros((cfg.n_trials, len(cfg.horizons)), dtype=np.float64)

    for i in range(cfg.n_trials):
        idx = int(rng.integers(0, o_test.shape[0]))
        obs = o_test[idx]
        acts = a_test[idx]
        xtrue = x_test[idx]

        # Delta derived from WM at t=0.
        delta = wm_attack_delta_gru(wm, obs, acts, xtrue, eps=eps, target_step=1)

        z_wm_clean = wm(obs.unsqueeze(0), acts.unsqueeze(0))[0].detach()
        z_wm_adv = wm(
            apply_delta_at_step(obs, delta, 0).unsqueeze(0), acts.unsqueeze(0)
        )[0].detach()
        wm_err[i] = torch.norm(z_wm_adv - z_wm_clean, dim=-1).cpu().numpy()

        z_ss_clean = ss(obs.unsqueeze(0), acts.unsqueeze(0))[0].detach()
        z_ss_adv0 = ss(
            apply_delta_at_step(obs, delta, 0).unsqueeze(0), acts.unsqueeze(0)
        )[0].detach()
        ss_err_sym[i] = torch.norm(z_ss_adv0 - z_ss_clean, dim=-1).cpu().numpy()

        # Asymmetric denominator in paper Definition 1: apply same delta at current step k.
        for k in range(t):
            z_ss_advk = ss(
                apply_delta_at_step(obs, delta, k).unsqueeze(0), acts.unsqueeze(0)
            )[0].detach()
            ss_err_asym[i, k] = torch.norm(z_ss_advk[k] - z_ss_clean[k], p=2).item()

        # Reward proxy = negative prediction MSE to hidden true state.
        r_wm_clean = -((z_wm_clean - xtrue) ** 2).mean(dim=-1)
        r_wm_adv = -((z_wm_adv - xtrue) ** 2).mean(dim=-1)
        r_ss_clean = -((z_ss_clean - xtrue) ** 2).mean(dim=-1)
        r_ss_adv = -((z_ss_adv0 - xtrue) ** 2).mean(dim=-1)
        for h_idx, h in enumerate(cfg.horizons):
            c_wm = r_wm_clean[:h].sum().item()
            a_wm = r_wm_adv[:h].sum().item()
            c_ss = r_ss_clean[:h].sum().item()
            a_ss = r_ss_adv[:h].sum().item()
            wm_clean_abs[i, h_idx] = c_wm
            wm_adv_abs[i, h_idx] = a_wm
            wm_rew_gap[i, h_idx] = c_wm - a_wm
            ss_rew_gap[i, h_idx] = c_ss - a_ss

    return {
        "wm_err": wm_err,
        "ss_err_asym": ss_err_asym,
        "ss_err_sym": ss_err_sym,
        "wm_rew_gap": wm_rew_gap,
        "ss_rew_gap": ss_rew_gap,
        "wm_clean_abs": wm_clean_abs,
        "wm_adv_abs": wm_adv_abs,
    }


def evaluate_budget_curve(
    cfg: Config,
    wm: GRUWorldModel,
    ss: SingleStepModel,
    data: Dict[str, torch.Tensor],
) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.seed + 11)
    rows = []
    for eps in cfg.eps_grid:
        wm_last, ss_last = [], []
        for _ in range(cfg.n_trials):
            idx = int(rng.integers(0, data["o_test"].shape[0]))
            obs = data["o_test"][idx]
            acts = data["a_test"][idx]
            xtrue = data["x_test"][idx]
            delta = wm_attack_delta_gru(wm, obs, acts, xtrue, eps=eps, target_step=1)
            z_wm_clean = wm(obs.unsqueeze(0), acts.unsqueeze(0))[0].detach()
            z_wm_adv = wm(
                apply_delta_at_step(obs, delta, 0).unsqueeze(0), acts.unsqueeze(0)
            )[0].detach()
            z_ss_clean = ss(obs.unsqueeze(0), acts.unsqueeze(0))[0].detach()
            z_ss_adv = ss(
                apply_delta_at_step(obs, delta, cfg.seq_len - 1).unsqueeze(0),
                acts.unsqueeze(0),
            )[0].detach()
            wm_last.append(torch.norm(z_wm_adv[-1] - z_wm_clean[-1], p=2).item())
            ss_last.append(torch.norm(z_ss_adv[-1] - z_ss_clean[-1], p=2).item())
        rows.append(
            {
                "epsilon": eps,
                "wm_last_mean": float(np.mean(wm_last)),
                "wm_last_se": se(np.array(wm_last)),
                "ss_last_mean": float(np.mean(ss_last)),
                "ss_last_se": se(np.array(ss_last)),
            }
        )
    return pd.DataFrame(rows)


def adversarial_finetune_gru(
    cfg: Config, model: GRUWorldModel, data: Dict[str, torch.Tensor]
) -> GRUWorldModel:
    """
    PGD-style adversarial fine-tuning on t=0 observation.
    """
    robust = GRUWorldModel(cfg)
    robust.load_state_dict(model.state_dict())
    opt = torch.optim.Adam(robust.parameters(), lr=8e-4)

    for _ in range(cfg.adv_ft_epochs):
        for obs, acts, xtrue in iterate_minibatches(
            data["o_train"], data["a_train"], data["x_train"], cfg.batch_size
        ):
            obs_adv = obs.clone().detach()
            for _step in range(cfg.adv_ft_steps):
                obs_adv.requires_grad_(True)
                pred_adv = robust(obs_adv, acts)
                loss_adv = F.mse_loss(pred_adv[:, :8], xtrue[:, :8])
                grad = torch.autograd.grad(loss_adv, obs_adv, retain_graph=False)[0]
                d0 = grad[:, 0]
                d0 = cfg.adv_ft_step_size * l2_normalize(d0)
                obs_adv = obs_adv.detach()
                obs_adv[:, 0] = obs_adv[:, 0] + d0
                delta0 = obs_adv[:, 0] - obs[:, 0]
                # L2 projection
                n = torch.norm(delta0, p=2, dim=-1, keepdim=True).clamp_min(1e-8)
                delta0 = delta0 * torch.clamp(cfg.adv_ft_eps / n, max=1.0)
                obs_adv[:, 0] = obs[:, 0] + delta0

            pred_clean = robust(obs, acts)
            pred_adv = robust(obs_adv.detach(), acts)
            loss_clean = F.mse_loss(pred_clean, xtrue)
            loss_adv = F.mse_loss(pred_adv, xtrue)
            sens = torch.norm(pred_adv[:, 1] - pred_clean[:, 1], dim=-1).mean()
            loss = (
                (1.0 - cfg.adv_ft_lambda) * loss_clean
                + cfg.adv_ft_lambda * loss_adv
                + cfg.adv_ft_lambda_sens * sens
            )
            opt.zero_grad()
            loss.backward()
            opt.step()

    return robust


def evaluate_rssm_proxy(
    cfg: Config, rssm: RSSMProxy, ss: SingleStepModel, data: Dict[str, torch.Tensor], eps: float
) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(cfg.seed + 19)
    t = cfg.seq_len
    wm_err = np.zeros((cfg.n_trials, t), dtype=np.float64)
    ss_err_asym = np.zeros((cfg.n_trials, t), dtype=np.float64)
    wm_rew_gap = np.zeros((cfg.n_trials, len(cfg.horizons)), dtype=np.float64)

    for i in range(cfg.n_trials):
        idx = int(rng.integers(0, data["o_test"].shape[0]))
        obs = data["o_test"][idx]
        acts = data["a_test"][idx]
        xtrue = data["x_test"][idx]
        delta = wm_attack_delta_rssm(rssm, obs, acts, xtrue, eps=eps, target_step=1)

        noise = torch.randn(1, t, cfg.dz)
        z_clean = rssm(
            obs.unsqueeze(0),
            acts.unsqueeze(0),
            use_posterior=True,
            posterior_mode="first_only",
            noise_eps=noise,
        )["z"][0].detach()
        z_adv = rssm(
            apply_delta_at_step(obs, delta, 0).unsqueeze(0),
            acts.unsqueeze(0),
            use_posterior=True,
            posterior_mode="first_only",
            noise_eps=noise,
        )["z"][0].detach()
        wm_err[i] = torch.norm(z_adv - z_clean, dim=-1).cpu().numpy()

        z_ss_clean = ss(obs.unsqueeze(0), acts.unsqueeze(0))[0].detach()
        for k in range(t):
            z_ss_advk = ss(
                apply_delta_at_step(obs, delta, k).unsqueeze(0), acts.unsqueeze(0)
            )[0].detach()
            ss_err_asym[i, k] = torch.norm(z_ss_advk[k] - z_ss_clean[k], p=2).item()

        # Reward proxy for RSSM uses decoded xhat.
        xhat_clean = rssm(
            obs.unsqueeze(0),
            acts.unsqueeze(0),
            use_posterior=True,
            posterior_mode="first_only",
            noise_eps=noise,
        )["xhat"][0].detach()
        xhat_adv = rssm(
            apply_delta_at_step(obs, delta, 0).unsqueeze(0),
            acts.unsqueeze(0),
            use_posterior=True,
            posterior_mode="first_only",
            noise_eps=noise,
        )["xhat"][0].detach()
        r_clean = -((xhat_clean - xtrue) ** 2).mean(dim=-1)
        r_adv = -((xhat_adv - xtrue) ** 2).mean(dim=-1)
        for h_idx, h in enumerate(cfg.horizons):
            wm_rew_gap[i, h_idx] = (r_clean[:h].sum() - r_adv[:h].sum()).item()

    return {"wm_err": wm_err, "ss_err_asym": ss_err_asym, "wm_rew_gap": wm_rew_gap}


def summarize_metrics(
    cfg: Config, eval_out: Dict[str, np.ndarray], label: str, outdir_tables: Path
) -> pd.DataFrame:
    wm_err = eval_out["wm_err"]
    ss_asym = eval_out["ss_err_asym"]
    ss_sym = eval_out.get("ss_err_sym")

    rows = []
    for k in range(cfg.seq_len):
        a_asym = float(wm_err[:, k].mean() / max(ss_asym[:, k].mean(), cfg.eps_floor))
        row = {
            "model": label,
            "step": k + 1,
            "wm_err_mean": float(wm_err[:, k].mean()),
            "wm_err_se": se(wm_err[:, k]),
            "ss_err_asym_mean": float(ss_asym[:, k].mean()),
            "ss_err_asym_se": se(ss_asym[:, k]),
            "A_asym": a_asym,
        }
        if ss_sym is not None:
            row["ss_err_sym_mean"] = float(ss_sym[:, k].mean())
            row["ss_err_sym_se"] = se(ss_sym[:, k])
            row["A_sym_epsfloor"] = float(
                wm_err[:, k].mean() / max(ss_sym[:, k].mean(), cfg.eps_floor)
            )
        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(outdir_tables / f"{label}_trajectory_metrics.csv", index=False)
    return df


def make_figures(
    cfg: Config,
    gru_df: pd.DataFrame,
    budget_before: pd.DataFrame,
    budget_after: pd.DataFrame,
    rew_df: pd.DataFrame,
    rssm_df: pd.DataFrame,
    outdir_fig: Path,
) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # A: Trajectory error over steps (GRU vs SS asym denominator)
    ax = axes[0, 0]
    ax.plot(gru_df["step"], gru_df["wm_err_mean"], label="WM (GRU-RSSM proxy)", lw=2.2)
    ax.plot(gru_df["step"], gru_df["ss_err_asym_mean"], label="SS (asym denom)", lw=2.2)
    ax.fill_between(
        gru_df["step"],
        gru_df["wm_err_mean"] - gru_df["wm_err_se"],
        gru_df["wm_err_mean"] + gru_df["wm_err_se"],
        alpha=0.18,
    )
    ax.set_title("A. Latent Error Trajectory (eps=0.05)")
    ax.set_xlabel("Rollout Step")
    ax.set_ylabel("L2 Latent Error")
    ax.legend()
    ax.grid(alpha=0.25)

    # B: Asymmetric vs symmetric amplification ratio
    ax = axes[0, 1]
    ax.plot(gru_df["step"], gru_df["A_asym"], label="A_k (asymmetric, paper def.)", lw=2.2)
    if "A_sym_epsfloor" in gru_df:
        ax.plot(
            gru_df["step"],
            gru_df["A_sym_epsfloor"],
            label="A_k (symmetric, eps-floor denominator)",
            lw=2.0,
        )
    ax.set_yscale("log")
    ax.set_title("B. Amplification Ratio: Definition Check")
    ax.set_xlabel("Step k")
    ax.set_ylabel("Amplification Ratio (log scale)")
    ax.legend()
    ax.grid(alpha=0.25)

    # C: Mitigation budget curves (k=30 error)
    ax = axes[1, 0]
    ax.plot(
        budget_before["epsilon"],
        budget_before["wm_last_mean"],
        marker="o",
        label="WM before mitigation",
    )
    ax.plot(
        budget_after["epsilon"],
        budget_after["wm_last_mean"],
        marker="o",
        label="WM after mitigation",
    )
    ax.plot(
        budget_before["epsilon"],
        budget_before["ss_last_mean"],
        marker="x",
        linestyle="--",
        label="SS baseline",
    )
    ax.set_title("C. Mitigation Ablation: Final-Step Error vs Epsilon")
    ax.set_xlabel("Perturbation Budget (epsilon)")
    ax.set_ylabel("Error at k=30")
    ax.legend()
    ax.grid(alpha=0.25)

    # D: RSSM proxy vs GRU at key steps.
    ax = axes[1, 1]
    steps = [1, 5, 10]
    x = np.arange(len(steps))
    gru_vals = [float(gru_df.loc[gru_df["step"] == s, "A_asym"].iloc[0]) for s in steps]
    rssm_vals = [float(rssm_df.loc[rssm_df["step"] == s, "A_asym"].iloc[0]) for s in steps]
    w = 0.36
    ax.bar(x - w / 2, gru_vals, width=w, label="GRU WM")
    ax.bar(x + w / 2, rssm_vals, width=w, label="RSSM proxy")
    ax.set_title("D. Realism Bridge: A_k on RSSM Proxy")
    ax.set_xticks(x)
    ax.set_xticklabels([f"k={s}" for s in steps])
    ax.set_ylabel("A_k (asym)")
    ax.legend()
    ax.grid(alpha=0.25, axis="y")

    fig.tight_layout()
    fig.savefig(outdir_fig / "world_model_attack_revisions.png", dpi=220)
    plt.close(fig)

    # Reward baseline figure for panel-C criticism fix.
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(rew_df["horizon"], rew_df["wm_clean_mean"], marker="o", label="WM clean return")
    ax.plot(rew_df["horizon"], rew_df["wm_adv_mean"], marker="o", label="WM perturbed return")
    ax.plot(rew_df["horizon"], rew_df["wm_gap_mean"], marker="x", linestyle="--", label="WM gap")
    ax.plot(rew_df["horizon"], rew_df["ss_gap_mean"], marker="x", linestyle="--", label="SS gap")
    ax.set_title("Absolute Reward Baseline and Gap vs Horizon")
    ax.set_xlabel("Planning Horizon H")
    ax.set_ylabel("Cumulative Reward Proxy")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(outdir_fig / "reward_baseline_and_gap.png", dpi=220)
    plt.close(fig)


def main() -> None:
    cfg = Config()
    set_seed(cfg.seed)

    root = Path(".")  # outputs written relative to working directory
    out_tables = root / "results" / "tables"
    out_fig = root / "results" / "figures"
    out_tables.mkdir(parents=True, exist_ok=True)
    out_fig.mkdir(parents=True, exist_ok=True)

    data = build_synth_dataset(cfg)

    ss = SingleStepModel(cfg)
    gru = GRUWorldModel(cfg)
    rssm = RSSMProxy(cfg)

    train_ss(cfg, ss, data)
    train_gru(cfg, gru, data)
    train_rssm(cfg, rssm, data)

    # Baseline evaluation (deterministic GRU WM).
    eval_gru = evaluate_gru_vs_ss(cfg, gru, ss, data, eps=cfg.eps_default)
    gru_df = summarize_metrics(cfg, eval_gru, "gru_wm", out_tables)
    budget_before = evaluate_budget_curve(cfg, gru, ss, data)
    budget_before.to_csv(out_tables / "budget_curve_before_mitigation.csv", index=False)

    # Mitigation ablation.
    gru_robust = adversarial_finetune_gru(cfg, gru, data)
    eval_gru_robust = evaluate_gru_vs_ss(cfg, gru_robust, ss, data, eps=cfg.eps_default)
    robust_df = summarize_metrics(cfg, eval_gru_robust, "gru_wm_robust", out_tables)
    budget_after = evaluate_budget_curve(cfg, gru_robust, ss, data)
    budget_after.to_csv(out_tables / "budget_curve_after_mitigation.csv", index=False)

    # RSSM proxy validation.
    eval_rssm = evaluate_rssm_proxy(cfg, rssm, ss, data, eps=cfg.eps_default)
    rssm_df = summarize_metrics(cfg, eval_rssm, "rssm_proxy_wm", out_tables)

    # Reward baseline and gap table (for panel-C fix).
    rew_rows = []
    for i, h in enumerate(cfg.horizons):
        wm_clean = eval_gru["wm_clean_abs"][:, i]
        wm_adv = eval_gru["wm_adv_abs"][:, i]
        wm_gap = eval_gru["wm_rew_gap"][:, i]
        ss_gap = eval_gru["ss_rew_gap"][:, i]
        rew_rows.append(
            {
                "horizon": h,
                "wm_clean_mean": float(np.mean(wm_clean)),
                "wm_clean_se": se(wm_clean),
                "wm_adv_mean": float(np.mean(wm_adv)),
                "wm_adv_se": se(wm_adv),
                "wm_gap_mean": float(np.mean(wm_gap)),
                "wm_gap_se": se(wm_gap),
                "ss_gap_mean": float(np.mean(ss_gap)),
                "ss_gap_se": se(ss_gap),
            }
        )
    rew_df = pd.DataFrame(rew_rows)
    rew_df.to_csv(out_tables / "reward_gap_with_baseline.csv", index=False)

    # Mitigation summary table.
    mit_rows = []
    for step in [1, 5, 10]:
        before = float(gru_df.loc[gru_df["step"] == step, "A_asym"].iloc[0])
        after = float(robust_df.loc[robust_df["step"] == step, "A_asym"].iloc[0])
        mit_rows.append(
            {
                "step": step,
                "A_before": before,
                "A_after": after,
                "pct_reduction": 100.0 * (before - after) / max(before, 1e-9),
            }
        )
    mit_df = pd.DataFrame(mit_rows)
    mit_df.to_csv(out_tables / "mitigation_reduction_summary.csv", index=False)

    make_figures(
        cfg=cfg,
        gru_df=gru_df,
        budget_before=budget_before,
        budget_after=budget_after,
        rew_df=rew_df,
        rssm_df=rssm_df,
        outdir_fig=out_fig,
    )

    key = {
        "A1_gru_asym_before": float(gru_df.loc[gru_df["step"] == 1, "A_asym"].iloc[0]),
        "A1_gru_asym_after": float(robust_df.loc[robust_df["step"] == 1, "A_asym"].iloc[0]),
        "A1_rssm_asym": float(rssm_df.loc[rssm_df["step"] == 1, "A_asym"].iloc[0]),
        "A5_gru_asym_before": float(gru_df.loc[gru_df["step"] == 5, "A_asym"].iloc[0]),
        "A10_gru_asym_before": float(gru_df.loc[gru_df["step"] == 10, "A_asym"].iloc[0]),
        "wm_gap_H30": float(rew_df.loc[rew_df["horizon"] == 30, "wm_gap_mean"].iloc[0]),
        "ss_gap_H30": float(rew_df.loc[rew_df["horizon"] == 30, "ss_gap_mean"].iloc[0]),
    }
    (root / "results" / "summary_metrics.json").write_text(
        json.dumps(key, indent=2), encoding="utf-8"
    )

    # Paper-ready bullet summary.
    md = []
    md.append("# Experiment Update (Paper-Ready)")
    md.append("")
    md.append(f"- Trials: **N={cfg.n_trials}**, steps: **K={cfg.seq_len}**, epsilon default: **{cfg.eps_default}**.")
    md.append(
        f"- GRU WM asym amplification: **A1={key['A1_gru_asym_before']:.2f}x**, "
        f"**A5={key['A5_gru_asym_before']:.2f}x**, **A10={key['A10_gru_asym_before']:.2f}x**."
    )
    md.append(
        f"- Mitigation (adversarial fine-tuning) reduced **A1** from "
        f"**{key['A1_gru_asym_before']:.2f}x** to **{key['A1_gru_asym_after']:.2f}x**."
    )
    md.append(f"- RSSM proxy asym amplification at step 1: **A1={key['A1_rssm_asym']:.2f}x**.")
    md.append(
        f"- Reward impact at H=30 (absolute baseline reported): WM gap **{key['wm_gap_H30']:.4f}**, "
        f"SS gap **{key['ss_gap_H30']:.4f}**."
    )
    md.append("")
    md.append("See tables in `results/tables/` and figures in `results/figures/`.")
    (root / "results" / "paper_ready_results.md").write_text("\n".join(md), encoding="utf-8")

    print("Saved outputs under:", root / "results")
    print(json.dumps(key, indent=2))


if __name__ == "__main__":
    main()
